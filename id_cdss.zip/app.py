# app code placeholder
print("app")